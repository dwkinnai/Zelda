/**
 * this class is the title animation used in the start screen
 * @author josuerojas
 *
 */
public class Title extends Animation{

	public Title() {
		super("Images/StartScreen/title_", 15, 6, ".png");
	}
	public Title(int w, int h) {
		super("Images/StartScreen/title_", 15, 6, ".png",w,h);
	}

	
}
